package com.gamenative.fruitymatch.fruit_item;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public class Fruit_Item {

    public static final String COIN = "Coin";
    public static final String HAMMER = "Hammer";
    public static final String BOMB = "Bomb";
    public static final String GLOVE = "Gloves";

}
