package com.gamenative.fruitymatch.fruit_game.tutorial;

import com.nativegame.natyengine.ui.GameActivity;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public interface Fruit_Tutorial {

    void show(GameActivity activity);

}
