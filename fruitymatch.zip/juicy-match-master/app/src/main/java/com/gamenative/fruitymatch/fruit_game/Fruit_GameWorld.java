package com.gamenative.fruitymatch.fruit_game;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public class Fruit_GameWorld {

    public static final int WORLD_WIDTH = 2760;
    public static final int WORLD_HEIGHT = 8280;

}
