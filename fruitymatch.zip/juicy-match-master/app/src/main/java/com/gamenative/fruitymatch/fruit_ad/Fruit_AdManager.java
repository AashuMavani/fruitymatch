package com.gamenative.fruitymatch.fruit_ad;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.NonNull;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.ads.MaxAppOpenAd;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.mediation.ads.MaxRewardedAd;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.gamenative.fruitymatch.R;
import com.google.gson.Gson;
import com.nativegame.natyengine.util.ResourceUtils;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public class Fruit_AdManager {
    private static boolean isShowingAds = false;
    private static Activity currentActivity;
    private static AdShownListener adShownListener;
    private static AdShownListener adShownListenerInterstitial;
    private static MaxAppOpenAd appOpenAdAppLovin;
    private static MaxInterstitialAd interstitialAdAppLovin;
    private static MaxRewardedAd rewardedAppLovinAd;
    private static AdShownListener adShownListenerRewarded;
    private static VideoAdShownListener videoAdShownListenerInterstitial;
    private static VideoAdShownListener videoAdShownListenerRewarded;
    public static String adFailUrl;

    public interface AdShownListener {
        void onAdDismiss();
    }

    public interface VideoAdShownListener {
        void onAdDismiss(boolean isAdShown);
    }

    public static void showAppLovinInterstitialAd(Activity activity, VideoAdShownListener adShownListener1, boolean isFromVideoList) {
        try {
            currentActivity = activity;
            videoAdShownListenerInterstitial = adShownListener1;
            if (interstitialAdAppLovin != null && interstitialAdAppLovin.isReady() && !isIsShowingAds() && (currentActivity != null && !currentActivity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                Fruit_Common_Utils.showAdLoader(activity, "Loading video...");
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Fruit_Common_Utils.dismissAdLoader();
                        isShowingAds = true;
                        interstitialAdAppLovin.showAd();
                    }
                }, 1000);
            } else {
                if (interstitialAdAppLovin == null && Fruit_Common_Utils.isLoadAppLovinInterstitialAds()) {
                    Fruit_Common_Utils.showAdLoader(activity, "Loading video...");
                    loadAdMobInterstitialAds(true);
                } else {
                    if (videoAdShownListenerInterstitial != null) {
                        videoAdShownListenerInterstitial.onAdDismiss(false);
                        videoAdShownListenerInterstitial = null;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showAppLovinInterstitialAd(Activity activity, AdShownListener adShownListener1) {
        try {
            currentActivity = activity;
            adShownListenerInterstitial = adShownListener1;
            if (interstitialAdAppLovin != null && interstitialAdAppLovin.isReady() && !isIsShowingAds() && (currentActivity != null && !currentActivity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                Fruit_Common_Utils.showAdLoader(activity, "Loading video ads...");
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Fruit_Common_Utils.dismissAdLoader();
                        isShowingAds = true;
                        interstitialAdAppLovin.showAd();
                    }
                }, 1000);
            } else {
                if (interstitialAdAppLovin == null && Fruit_Common_Utils.isLoadAppLovinInterstitialAds()) {
                    Fruit_Common_Utils.showAdLoader(activity, "Loading video ads...");
                    loadAdMobInterstitialAds(true);
                } else {
                    if (adShownListenerInterstitial != null) {
                        adShownListenerInterstitial.onAdDismiss();
                        adShownListenerInterstitial = null;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadAdMobInterstitialAds(boolean isShowAdAfterLoading) {
        Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
        if (Fruit_Common_Utils.isLoadAppLovinInterstitialAds()) {
            interstitialAdAppLovin = new MaxInterstitialAd(Fruit_Common_Utils.getRandomAdUnitId(responseMain.getLovinInterstitialID()), getCurrentActivity());
            interstitialAdAppLovin.setListener(new MaxAdListener() {
                @Override
                public void onAdLoaded(MaxAd ad) {
                    Fruit_Common_Utils.dismissAdLoader();
                    if (isShowAdAfterLoading && interstitialAdAppLovin != null && interstitialAdAppLovin.isReady() && !isIsShowingAds() && (currentActivity != null && !currentActivity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                        isShowingAds = true;
                        interstitialAdAppLovin.showAd();
                    }
                }

                @Override
                public void onAdDisplayed(MaxAd ad) {

                }

                @Override
                public void onAdHidden(MaxAd ad) {
                    Fruit_Common_Utils.dismissAdLoader();
                    isShowingAds = false;
                    if (adShownListenerInterstitial != null) {
                        adShownListenerInterstitial.onAdDismiss();
                        adShownListenerInterstitial = null;
                    }
                    if (videoAdShownListenerInterstitial != null) {
                        videoAdShownListenerInterstitial.onAdDismiss(true);
                        videoAdShownListenerInterstitial = null;
                    }
                    interstitialAdAppLovin = null;
                    loadAdMobInterstitialAds(false);
                }

                @Override
                public void onAdClicked(MaxAd ad) {

                }

                @Override
                public void onAdLoadFailed(String adUnitId, MaxError error) {

                    Fruit_Common_Utils.dismissAdLoader();
                    isShowingAds = false;
                    if (adShownListenerInterstitial != null) {
                        adShownListenerInterstitial.onAdDismiss();
                        adShownListenerInterstitial = null;
                    }
                    if (videoAdShownListenerInterstitial != null) {
                        videoAdShownListenerInterstitial.onAdDismiss(false);
                        videoAdShownListenerInterstitial = null;
                    }
                    interstitialAdAppLovin = null;
                    if (isShowAdAfterLoading) {
                        Fruit_Common_Utils.openUrl(currentActivity, adFailUrl);
                    }
                }

                @Override
                public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                    isShowingAds = false;
                    if (adShownListenerInterstitial != null) {
                        adShownListenerInterstitial.onAdDismiss();
                        adShownListenerInterstitial = null;
                    }
                    if (videoAdShownListenerInterstitial != null) {
                        videoAdShownListenerInterstitial.onAdDismiss(false);
                        videoAdShownListenerInterstitial = null;
                    }
                    interstitialAdAppLovin = null;
                    if (isShowAdAfterLoading) {
                        Fruit_Common_Utils.openUrl(currentActivity, adFailUrl);
                    }
                    loadAdMobInterstitialAds(false);
                }
            });

            // Load the first ad
            interstitialAdAppLovin.loadAd();
        }
    }

    public static void loadAppOpenAdd(final Context context) {
        //AppLogger.getInstance().e("loadAppOpenAdd loadAppOpenAdd STARTED: ", "CALLED===");
        Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
        if (Fruit_Common_Utils.isShowAppLovinAppOpenAds()) {
            appOpenAdAppLovin = new MaxAppOpenAd(Fruit_Common_Utils.getRandomAdUnitId(responseMain.getLovinAppOpenID()), Fruit_App_Controller.getContext());
            appOpenAdAppLovin.setListener(new MaxAdListener() {
                @Override
                public void onAdLoaded(MaxAd ad) {
                    try {
                        Fruit_App_Controller.getContext().sendBroadcast(new Intent(Fruit_Constants.APP_OPEN_ADD_LOADED).setPackage(Fruit_App_Controller.getContext().getPackageName()));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onAdDisplayed(MaxAd ad) {
                    //AppLogger.getInstance().e("Applovin AppOpen onAdDisplayed: ", "CALLED===");
                }

                @Override
                public void onAdHidden(MaxAd ad) {
                    //AppLogger.getInstance().e("Applovin AppOpen onAdHidden: ", "CALLED===");
                    appOpenAdAppLovin = null;
                    isShowingAds = false;
                    dismissAppOpenAdListener();
                    loadAppOpenAdd(Fruit_App_Controller.getContext());
                }

                @Override
                public void onAdClicked(MaxAd ad) {
                    //AppLogger.getInstance().e("Applovin AppOpen onAdClicked: ", "CALLED===");
                }

                @Override
                public void onAdLoadFailed(String adUnitId, MaxError error) {
                    //AppLogger.getInstance().e("Applovin AppOpen onAdLoadFailed: ", "CALLED===");
                }

                @Override
                public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                    //AppLogger.getInstance().e("Applovin AppOpen onAdDisplayFailed: ", "CALLED===");
                    dismissAppOpenAdListener();
                    isShowingAds = false;
                    loadAppOpenAdd(Fruit_App_Controller.getContext());
                }
            });
            appOpenAdAppLovin.loadAd();
        } else {
            dismissAppOpenAdListener();
            isShowingAds = false;
        }
    }

    private static void dismissAppOpenAdListener() {
        if (adShownListener != null) {
            adShownListener.onAdDismiss();
            adShownListener = null;
        } else {
            // User was not getting moved to main screen if app goes in background while displaying ap open ad as static adShownListener object was getting null when app goes in background
            Fruit_App_Controller.getContext().sendBroadcast(new Intent(Fruit_Constants.APP_OPEN_ADD_DISMISSED).setPackage(Fruit_App_Controller.getContext().getPackageName()));
        }
    }

    public static void showAppOpenAdd(Activity activity, AdShownListener adShownListener1) {
        try {
            adShownListener = adShownListener1;
            if (appOpenAdAppLovin != null && appOpenAdAppLovin.isReady() && (activity != null && !activity.isFinishing()) && !isIsShowingAds() && Fruit_Activity_Manager.appInForeground) {
                isShowingAds = true;
                appOpenAdAppLovin.showAd();
            } else {
                if (adShownListener != null) {
                    adShownListener.onAdDismiss();
                    adShownListener = null;
                }
                if (Fruit_Common_Utils.isShowAppLovinAppOpenAds() && appOpenAdAppLovin == null) {
                    loadAppOpenAdd(Fruit_App_Controller.getContext());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isIsShowingAds() {
        return isShowingAds;
    }

    public static Activity getCurrentActivity() {
        return currentActivity;
    }

    public static void setCurrentActivity(Activity activity) {
//        //AppLogger.getInstance().e("SET ACT1", "" + activity);
        if (!isShowingAds) {
            //AppLogger.getInstance().e("SET ACTIVITY", "=" + activity);
            currentActivity = activity;
        }
    }

    public static void loadRewardedAd(boolean isShowAdAfterLoading) {
        Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
        if (Fruit_Common_Utils.isLoadAppLovinRewardedAds()) {
            rewardedAppLovinAd = MaxRewardedAd.getInstance(Fruit_Common_Utils.getRandomAdUnitId(responseMain.getLovinRewardID()), getCurrentActivity());
            rewardedAppLovinAd.setListener(new MaxRewardedAdListener() {
                @Override
                public void onUserRewarded(MaxAd ad, MaxReward reward) {

                }

                @Override
                public void onRewardedVideoStarted(MaxAd ad) {

                }

                @Override
                public void onRewardedVideoCompleted(MaxAd ad) {

                }

                @Override
                public void onAdLoaded(MaxAd ad) {
                    //AppLogger.getInstance().e("APPLOVIN REWARDED", "REWARD :onAdLoaded");
                    Fruit_Common_Utils.dismissAdLoader();
                    if (isShowAdAfterLoading && rewardedAppLovinAd != null && rewardedAppLovinAd.isReady() && !isIsShowingAds() && (currentActivity != null && !currentActivity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                        //AppLogger.getInstance().e("APPLOVIN REWARDED SHOW WHEN LOADED===", "REWARD :onAdLoaded");
                        isShowingAds = true;
                        rewardedAppLovinAd.showAd();
                    }
                }

                @Override
                public void onAdDisplayed(MaxAd ad) {

                }

                @Override
                public void onAdHidden(MaxAd ad) {
                    //AppLogger.getInstance().e("APPLOVIN REWARDED ", "REWARD INST:onAdHidden");
                    isShowingAds = false;
                    if (adShownListenerRewarded != null) {
                        adShownListenerRewarded.onAdDismiss();
                        adShownListenerRewarded = null;
                    }
                    if (videoAdShownListenerRewarded != null) {
                        videoAdShownListenerRewarded.onAdDismiss(true);
                        videoAdShownListenerRewarded = null;
                    }
                    rewardedAppLovinAd = null;
                    loadRewardedAd(false);
                }

                @Override
                public void onAdClicked(MaxAd ad) {

                }

                @Override
                public void onAdLoadFailed(String adUnitId, MaxError error) {
                    Fruit_Common_Utils.dismissAdLoader();
                    //AppLogger.getInstance().e("APPLOVIN REWARDED FAIL", "REWARD INST:onAdLoadFailed");
                    isShowingAds = false;
                    if (adShownListenerRewarded != null) {
                        adShownListenerRewarded.onAdDismiss();
                        adShownListenerRewarded = null;
                    }
                    if (videoAdShownListenerRewarded != null) {
                        videoAdShownListenerRewarded.onAdDismiss(false);
                        videoAdShownListenerRewarded = null;
                    }
                    rewardedAppLovinAd = null;
                    if (isShowAdAfterLoading) {
                        Fruit_Common_Utils.openUrl(currentActivity, adFailUrl);
                    }
                }

                @Override
                public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                    //AppLogger.getInstance().e("APPLOVIN REWARDED FAIL", "REWARD INST:onAdDisplayFailed");
                    isShowingAds = false;
                    if (adShownListenerRewarded != null) {
                        adShownListenerRewarded.onAdDismiss();
                        adShownListenerRewarded = null;
                    }
                    if (videoAdShownListenerRewarded != null) {
                        videoAdShownListenerRewarded.onAdDismiss(false);
                        videoAdShownListenerRewarded = null;
                    }
                    rewardedAppLovinAd = null;
                    if (isShowAdAfterLoading) {
                        Fruit_Common_Utils.openUrl(currentActivity, adFailUrl);
                    }
                    loadRewardedAd(false);
                }
            });
            rewardedAppLovinAd.loadAd();
        }
    }

    public static void showAppLovinRewardedAd(Activity activity, VideoAdShownListener adShownListener1, boolean isFromVideoList) {
        try {
            currentActivity = activity;
            videoAdShownListenerRewarded = adShownListener1;
            if (rewardedAppLovinAd != null && rewardedAppLovinAd.isReady() && !isIsShowingAds() && (activity != null && !activity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                Fruit_Common_Utils.showAdLoader(activity, "Loading video...");
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Fruit_Common_Utils.dismissAdLoader();
                        isShowingAds = true;
                        rewardedAppLovinAd.showAd();
                    }
                }, 1000);
            } else {
                if (rewardedAppLovinAd == null && Fruit_Common_Utils.isLoadAppLovinRewardedAds()) {
                    Fruit_Common_Utils.showAdLoader(activity, "Loading video...");
                    loadRewardedAd(true);
                } else {
                    if (videoAdShownListenerRewarded != null) {
                        videoAdShownListenerRewarded.onAdDismiss(false);
                        videoAdShownListenerRewarded = null;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showAppLovinRewardedAd(Activity activity, AdShownListener adShownListener1) {
        try {
            currentActivity = activity;
            adShownListenerRewarded = adShownListener1;
            if (rewardedAppLovinAd != null && rewardedAppLovinAd.isReady() && !isIsShowingAds() && (activity != null && !activity.isFinishing()) && Fruit_Activity_Manager.appInForeground) {
                Fruit_Common_Utils.showAdLoader(activity, "Loading video ads...");
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Fruit_Common_Utils.dismissAdLoader();
                        isShowingAds = true;
                        rewardedAppLovinAd.showAd();
                    }
                }, 1000);
            } else {
                if (rewardedAppLovinAd == null && Fruit_Common_Utils.isLoadAppLovinRewardedAds()) {
                    Fruit_Common_Utils.showAdLoader(activity, "Loading video ads...");
                    loadRewardedAd(true);
                } else {
                    if (adShownListenerRewarded != null) {
                        adShownListenerRewarded.onAdDismiss();
                        adShownListenerRewarded = null;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private final Activity mActivity;

    private RewardedAd mRewardedAd;
    private AdRewardListener mListener;


    private boolean mRewardEarned = false;
    private boolean mInterstitialEarned = false;

    //--------------------------------------------------------
    // Constructors
    //--------------------------------------------------------
    public Fruit_AdManager(Activity activity) {
        mActivity = activity;
        requestAd();
    }
    //========================================================

    //--------------------------------------------------------
    // Getter and Setter
    //--------------------------------------------------------
    public AdRewardListener getListener() {
        return mListener;
    }

    public void setListener(AdRewardListener listener) {
        mListener = listener;
    }
    //========================================================

    //--------------------------------------------------------
    // Methods
    //--------------------------------------------------------


    public void requestAd() {
        if (mRewardedAd != null) {
            return;
        }

        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(mActivity, ResourceUtils.getString(mActivity, R.string.txt_admob_reward),
                adRequest, new RewardedAdLoadCallback() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        mRewardedAd = null;
                        // Toast.makeText(mActivity, "Fail!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onAdLoaded(RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        // Toast.makeText(mActivity, "Succeed!", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public boolean showRewardAd() {
        if (mRewardedAd == null) {
            return false;
        }

        // Reset state
        mRewardEarned = false;

        mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdShowedFullScreenContent() {
                // Called when ad is shown
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                // Called when ad fails to show
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                // Called when ad is dismissed
                mRewardedAd = null;
                // Check if user dismiss Ad before earn
                if (!mRewardEarned) {
                    mListener.onLossReward();
                }
                // Prepare next ad
                requestAd();
            }
        });

        mRewardedAd.show(mActivity, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(RewardItem rewardItem) {
                mListener.onEarnReward();
                mRewardEarned = true;
                // Toast.makeText(mActivity, "Reward!", Toast.LENGTH_SHORT).show();
            }
        });

        return true;
    }
    //========================================================

    //--------------------------------------------------------
    // Inner Classes
    //--------------------------------------------------------
    public interface AdRewardListener {

        void onEarnReward();

        void onLossReward();

    }

    //========================================================




}
