package com.gamenative.fruitymatch.fruit_game.algorithm;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public interface Fruit_Algorithm {

    void initAlgorithm();

    void startAlgorithm();

    void removeAlgorithm();

}
