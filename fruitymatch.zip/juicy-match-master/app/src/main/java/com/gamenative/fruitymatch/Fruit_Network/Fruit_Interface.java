package com.gamenative.fruitymatch.Fruit_Network;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface Fruit_Interface {
    @GET
    Call<JsonObject> callApi(@Url String Value,//http://surgex.media-412.com/click
                             @Query("pid") String pid,//9
                             @Query("offer_id") String o_id,//1548
                             @Query("sub5") String installed_package_id,
                             @Query("sub3") String gaid,
                             @Query("sub2") String current_app_package_id,
                             @Query("sub1") String unique_click_id,//device_id
                             @Query("sub7") String ip_address);
}
