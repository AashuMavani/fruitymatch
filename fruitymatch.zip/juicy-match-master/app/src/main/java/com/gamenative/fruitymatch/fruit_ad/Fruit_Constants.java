package com.gamenative.fruitymatch.fruit_ad;

public class Fruit_Constants {
    public static String APP_OPEN_ADD_LOADED = "APP_OPEN_ADD_LOADED";
    public static String APP_OPEN_ADD_DISMISSED = "APP_OPEN_ADD_DISMISSED";
}
