package com.gamenative.fruitymatch.fruit_ad;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.gamenative.fruitymatch.R;
import com.google.gson.Gson;

import java.util.List;
import java.util.Random;

public class Fruit_Common_Utils {
    private static Dialog dialogLoader, dialogAdLoader;
    private static Handler handler1;

    public static void showProgressLoader(Context activity) {
        try {
            if (dialogLoader == null || !dialogLoader.isShowing()) {
                //AppLogger.getInstance().e("Activity Loader:", "=================LOADER===============" + activity);
                dialogLoader = new Dialog(activity, android.R.style.Theme_Light);
                dialogLoader.getWindow().setBackgroundDrawableResource(R.color.black_transparent);
                dialogLoader.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialogLoader.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                dialogLoader.setCancelable(true);
                dialogLoader.setCanceledOnTouchOutside(true);
                dialogLoader.setContentView(R.layout.fruit_dialog_loader);
                dialogLoader.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void showAdLoader(Context activity, String title) {
        try {
            if (dialogAdLoader == null || !dialogAdLoader.isShowing()) {
                dialogAdLoader = new Dialog(activity, android.R.style.Theme_Light);
                dialogAdLoader.getWindow().setBackgroundDrawableResource(R.color.black_transparent);
                dialogAdLoader.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialogAdLoader.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                dialogAdLoader.setCancelable(true);
                dialogAdLoader.setCanceledOnTouchOutside(true);
                dialogAdLoader.setContentView(R.layout.fruit_dialog_ads_loader);
                TextView tvTitle = dialogAdLoader.findViewById(R.id.tvTitle);
                tvTitle.setText(title);
                dialogAdLoader.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void dismissAdLoader() {
        try {
            if (dialogAdLoader != null && dialogAdLoader.isShowing()) {
                dialogAdLoader.dismiss();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static boolean isLoadAppLovinInterstitialAds() {
        try {
            Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
            if (responseMain.getIsAppLovinAdShow() != null && responseMain.getIsAppLovinAdShow().equals("1") && responseMain.getLovinInterstitialID() != null && responseMain.getLovinInterstitialID().size() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public static String getRandomAdUnitId(List<String> list) {
        return list.get(getRandomNumberBetweenRange(0, list.size()));
    }

    public static int getRandomNumberBetweenRange(int min, int max) {
        if (max == 0) {
            return 0;
        }
        Random r = new Random();
        int i1 = r.nextInt(max - min) + min;// min inclusive & max exclusive
        return i1;
    }

    public static void openUrl(Context c, String url) {
        if (!Fruit_Common_Utils.isStringNullOrEmpty(url)) {
            if (url.contains("/t.me/") || url.contains("telegram") || url.contains("facebook.com") || url.contains("instagram.com") || url.contains("youtube.com") || url.contains("play.google.com/store/apps/details") || url.contains("market.android.com/details")) {
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                try {
                    c.startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                    openUrlInChrome(c, url);
                }
            } else {
                openUrlInChrome(c, url);
            }
        }
    }
    private static void openUrlInChrome(Context c, String url) {
        //AppLogger.getInstance().e("URL openUrlInChrome :============", url);
        if (!Fruit_Common_Utils.isStringNullOrEmpty(url)) {
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            try {
                intent.setPackage("com.android.chrome");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    intent.setPackage(null);
                    c.startActivity(intent);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    setToast(c, "No application found to handle this url");
                }
            }
        }
    }

    public static void setToast(Context _mContext, String str) {
        Toast toast = Toast.makeText(_mContext, str, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }


    public static boolean isStringNullOrEmpty(String text) {
        return (text == null || text.trim().equals("null") || text.trim()
                .length() <= 0);
    }
    public static boolean isShowAppLovinAppOpenAds() {
        try {
            Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
            if (responseMain.getIsAppLovinAdShow() != null && responseMain.getIsAppLovinAdShow().equals("1") && responseMain.getLovinAppOpenID() != null && responseMain.getLovinAppOpenID().size() > 0)
                return true;
            else
                return false;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean isLoadAppLovinRewardedAds() {
        try {
            Fruit_Response_Model responseMain = new Gson().fromJson(Fruit_SharePrefs.getInstance().getString(Fruit_SharePrefs.HomeData), Fruit_Response_Model.class);
            if (responseMain.getIsAppLovinAdShow() != null && responseMain.getIsAppLovinAdShow().equals("1") && responseMain.getLovinRewardID() != null && responseMain.getLovinRewardID().size() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
