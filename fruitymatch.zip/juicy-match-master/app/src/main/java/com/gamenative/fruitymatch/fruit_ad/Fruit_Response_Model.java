package com.gamenative.fruitymatch.fruit_ad;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Fruit_Response_Model implements Serializable {
    @SerializedName("lovinInterstitialID")
    private List<String> lovinInterstitialID;
    @SerializedName("lovinRewardID")
    private List<String> lovinRewardID;
    @SerializedName("lovinNativeID")
    private List<String> lovinNativeID;
    @SerializedName("lovinBannerID")
    private List<String> lovinBannerID;
    @SerializedName("isAppLovinAdShow")
    private String isAppLovinAdShow;
    @SerializedName("lovinAppOpenID")
    private List<String> lovinAppOpenID;

    public List<String> getLovinInterstitialID() {
        return lovinInterstitialID;
    }

    public void setLovinInterstitialID(List<String> lovinInterstitialID) {
        this.lovinInterstitialID = lovinInterstitialID;
    }

    public List<String> getLovinRewardID() {
        return lovinRewardID;
    }

    public void setLovinRewardID(List<String> lovinRewardID) {
        this.lovinRewardID = lovinRewardID;
    }

    public List<String> getLovinNativeID() {
        return lovinNativeID;
    }

    public void setLovinNativeID(List<String> lovinNativeID) {
        this.lovinNativeID = lovinNativeID;
    }

    public List<String> getLovinBannerID() {
        return lovinBannerID;
    }

    public void setLovinBannerID(List<String> lovinBannerID) {
        this.lovinBannerID = lovinBannerID;
    }

    public String getIsAppLovinAdShow() {
        return isAppLovinAdShow;
    }

    public void setIsAppLovinAdShow(String isAppLovinAdShow) {
        this.isAppLovinAdShow = isAppLovinAdShow;
    }

    public List<String> getLovinAppOpenID() {
        return lovinAppOpenID;
    }

    public void setLovinAppOpenID(List<String> lovinAppOpenID) {
        this.lovinAppOpenID = lovinAppOpenID;
    }
}
