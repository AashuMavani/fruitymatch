package com.gamenative.fruitymatch.fruit_ad;

import android.content.Context;

public class Fruit_App_Controller {
    public static Context mContext;
    public static Context getContext() {
        return mContext;
    }


}
