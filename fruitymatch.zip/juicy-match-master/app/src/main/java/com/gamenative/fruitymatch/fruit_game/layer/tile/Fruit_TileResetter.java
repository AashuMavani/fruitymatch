package com.gamenative.fruitymatch.fruit_game.layer.tile;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public interface Fruit_TileResetter {

    void resetTile(Fruit_Tile tile);

}
