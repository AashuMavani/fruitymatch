package com.gamenative.fruitymatch.fruit_ad;


import android.content.Context;

import com.github.rtoshiro.secure.SecureSharedPreferences;

public class Fruit_SharePrefs {

    private static Fruit_SharePrefs instance = null;
    public static final String HomeData = "HomeData";
    private SecureSharedPreferences sharedPreferences;

    public Fruit_SharePrefs(Context Context) {
        this.sharedPreferences = new SecureSharedPreferences(Fruit_App_Controller.mContext);
    }


    public static Fruit_SharePrefs getInstance() {

        if (instance != null) {
            return instance;
        } else {
            return new Fruit_SharePrefs(Fruit_App_Controller.mContext);
        }
    }
    public String getString(String key) {
        return sharedPreferences.getString(key, "");
    }



}
