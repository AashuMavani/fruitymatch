package com.gamenative.fruitymatch.fruit_algorithm;

/**
 * Created by Oscar Liang on 2022/02/23
 */

public enum Fruit_TileState {
    IDLE,
    MATCH,
    WAITING,
    UNREACHABLE
}
